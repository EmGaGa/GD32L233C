int __wrap_printf(const char* fmt, ...)
{
    // You can implement your own printf to reduce the code size, because the printf is really a big function
}

